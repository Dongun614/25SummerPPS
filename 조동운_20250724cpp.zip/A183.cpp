#include <iostream>
using namespace std;
int main(int argc, char const *argv[]) {
    cout << "\\    /\\\n";
    cout << " )  ( ')\n";
    cout << "(  /  )\n";
    cout << " \\(__)|\n";
    return 0;
}