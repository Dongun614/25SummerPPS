#include <iostream>
 
using namespace std;
 
int main(int argc, char const *argv[]) {
 
	int year;
	cin >> year;
 
	cout << year - 543;
	return 0;
}